public enum Palo {
	ESPADA, ORO, COPA, BASTO
};